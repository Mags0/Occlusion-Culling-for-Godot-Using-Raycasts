Occlusion Culling gdscript setup.

1) Create a group for all the objects that will be affected by the occlusion culling.

2) Make sure the objects are/has child/is child of a staticbody, kinematicbody, rigidbody or area.

3) Attach Occlusion Culling.gd to any node.

4) Tell it which camera to use and the name of the group for the occlusion culling.